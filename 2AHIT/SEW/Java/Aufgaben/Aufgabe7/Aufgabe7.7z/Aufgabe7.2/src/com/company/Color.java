package com.company;

public enum Color
{
    BLACK,
    BROWN,
    RED,
    ORANGE,
    YELLOW,
    GREEN,
    BLUE,
    PURPLE,
    GREY,
    WHITE,
    GOLD,
    SILVER,
    NONE
}
