#ifndef LIBRARY_INCLUDED
#define LIBRARY_INDLUDED 1

int countCharacters(char *filename);
int countLines(char *filename);
int countWords(char *filename);

void Usage();

#endif // LIBRARY_INCLUDED
